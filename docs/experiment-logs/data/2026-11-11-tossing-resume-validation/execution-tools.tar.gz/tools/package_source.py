"""Archive committed validation source and dependency trees; never execute a simulator."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile


def digest(path):
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkout", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--commit", required=True)
    args = parser.parse_args()
    checkout = args.checkout.resolve()
    output = args.output.resolve()
    source_commit = subprocess.check_output(
        ["git", "-C", str(checkout), "rev-parse", args.commit], text=True
    ).strip()
    staging = output / ("source-staging-" + source_commit[:9])
    staging.mkdir(exist_ok=False)
    pieces = [(checkout, source_commit, "", ["src", "scripts", "configs", "pyproject.toml", "README.md", "LICENSE"])]
    refs = {}
    for name in ("reference/kindergarden", "reference/kinder-baselines"):
        revision = subprocess.check_output(
            ["git", "-C", str(checkout), "ls-tree", source_commit, name], text=True
        ).split()[2]
        refs[name] = revision
        pieces.append((checkout / name, revision, name + "/", []))
    for index, (repo, revision, prefix, paths) in enumerate(pieces):
        archive = output / f"source-piece-{source_commit[:9]}-{index}.tar"
        subprocess.run(
            ["git", "-C", str(repo), "archive", "--format=tar", f"--prefix={prefix}", f"--output={archive}", revision, *paths],
            check=True,
        )
        with tarfile.open(archive, "r") as tar:
            for member in tar:
                destination = staging / member.name
                if not destination.resolve().is_relative_to(staging):
                    raise ValueError(f"unsafe archive path: {member.name}")
                if member.issym() and not (destination.parent / member.linkname).resolve().is_relative_to(staging):
                    raise ValueError(f"unsafe archive symlink: {member.name}")
                if not (member.isfile() or member.isdir() or member.issym()):
                    raise ValueError(f"unsupported archive entry: {member.name}")
                tar.extract(member, path=staging)
    files = {}
    symlinks = {}
    for path in sorted(staging.rglob("*")):
        name = path.relative_to(staging).as_posix()
        if path.is_symlink():
            symlinks[name] = str(path.readlink())
        elif path.is_file():
            files[name] = digest(path)
    identity = {
        "source_commit": source_commit,
        "references": refs,
        "files_relative_to": "source",
        "files": files,
        "symlinks": symlinks,
        "versions": {"numpy": "1.26.4", "scipy": "1.14.0", "pydantic": "2.13.4", "mujoco": "3.3.7", "torch": "2.13.0+cpu", "gymnasium": "1.3.0", "kindergarden": "0.2.5", "kinder_models": "0.1.0", "pybullet_helpers": "0.1.2"},
        "downward_sha256": "a1781cdb9cbe8cb4382a13e7364a07f04815a20a854ecbe13634ceeaff29aa8a",
        "scope": "git archive of committed src/scripts/configs and exact two KINDER gitlinks; no hardware checkouts, live outputs, assets or Git metadata; CLI-required real-domain library source retained",
    }
    raw_identity = (json.dumps(identity, indent=2, sort_keys=True) + "\n").encode()
    (output / "source-identity.json").write_bytes(raw_identity)
    (output / "inputs/identity.json").write_bytes(raw_identity)
    archive = output / "source.tar.gz"
    with archive.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|") as tar:
                for path in sorted(staging.rglob("*")):
                    tar.add(path, arcname=path.relative_to(staging).as_posix(), recursive=False)
                entry = tarfile.TarInfo("source-identity.json")
                entry.size = len(raw_identity)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(raw_identity))
    verified = output / ("source-verified-" + source_commit[:9])
    verified.mkdir(exist_ok=False)
    with tarfile.open(archive, "r:gz") as tar:
        tar.extractall(path=verified)
    for name, expected in files.items():
        if digest(verified / name) != expected:
            raise ValueError(f"extracted source hash mismatch: {name}")
    for name, target in symlinks.items():
        if str((verified / name).readlink()) != target:
            raise ValueError(f"extracted source symlink mismatch: {name}")
    archive_digest = digest(archive)
    (output / "source.tar.gz.sha256").write_text(f"{archive_digest}  source.tar.gz\n")
    print(json.dumps({"source_commit": source_commit, "archive": str(archive), "archive_bytes": archive.stat().st_size, "archive_sha256": archive_digest, "files_verified": len(files), "symlinks_verified": len(symlinks), "references": refs}, indent=2))


if __name__ == "__main__":
    main()
