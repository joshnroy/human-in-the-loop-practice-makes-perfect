"""One bounded Curtis checkpoint proof; run only through validation.sbatch."""
import argparse
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def preflight(root, source):
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("simulation proof requires a Slurm allocation")
    identity = json.loads((root / "inputs/identity.json").read_text())
    if not identity.get("source_commit") or not identity.get("files"):
        raise ValueError("identity.json must name source_commit and source-relative files/SHA256 map")
    for name, expected in identity["files"].items():
        if digest(source / name) != expected:
            raise ValueError(f"source identity mismatch: {name}")
    modules = {}
    for name in ("hitl_pmp", "kinder", "kinder_models", "pybullet_helpers", "gurobipy"):
        module = importlib.import_module(name)
        path = Path(module.__file__).resolve()
        modules[name] = str(path)
        if name in {"hitl_pmp", "kinder", "kinder_models"} and not path.is_relative_to(source):
            raise ValueError(f"{name} escaped current source: {path}")
    versions = {name: importlib.metadata.version(name) for name in
                ("numpy", "scipy", "pydantic", "mujoco", "torch", "gymnasium", "kindergarden", "kinder_models", "pybullet_helpers")}
    for name, expected in identity.get("versions", {}).items():
        if versions[name] != expected:
            raise ValueError(f"runtime package mismatch: {name}")
    planner = Path(os.environ["FD_EXEC_PATH"]) / "builds/release/bin/downward"
    planner_hash = digest(planner)
    if planner_hash != identity.get("downward_sha256", "a1781cdb9cbe8cb4382a13e7364a07f04815a20a854ecbe13634ceeaff29aa8a"):
        raise ValueError("planner executable hash mismatch")
    import gurobipy as gp
    model = gp.Model("resume-license-probe")
    model.Params.OutputFlag = 0
    variable = model.addVar(lb=0)
    model.setObjective(variable)
    model.optimize()
    if model.Status != gp.GRB.OPTIMAL:
        raise RuntimeError("Gurobi compute-node probe failed")
    write(root / "preflight.json", {"identity": identity, "modules": modules, "versions": versions,
          "python": sys.version, "executable": sys.executable, "planner_sha256": planner_hash,
          "gurobi_status": model.Status, "environment": {k: v for k, v in os.environ.items() if
          k.startswith("SLURM_") or k in {"PYTHONPATH", "PYTHONHASHSEED", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS", "FD_EXEC_PATH", "LD_PRELOAD"}}})
    model.dispose()


def shared_flags(root):
    historical = json.loads((root / "inputs/historical-config.json").read_text())["args"]
    args = []
    keys = ("practice_step_budget", "num_cycles", "evaluation_control_steps", "human_skill_steps",
            "sampler_max_train_iters", "pomdp_solver", "pomdp_determinized_variant",
            "pomdp_max_search_iterations", "pomdp_competence_model", "pomdp_competence_evidence",
            "pomdp_inference_engine", "pomdp_grid_competence_bins", "pomdp_grid_learning_rate_bins",
            "pomdp_competence_process_noise_std", "pomdp_learning_rate_decay", "pomdp_learning_rate_max",
            "pomdp_learning_rate_process_noise_std", "pomdp_learning_time_scale", "pomdp_linear_cost_lambda",
            "pomdp_num_particles", "pomdp_num_samples", "pomdp_draw_scope", "pomdp_observation_probability_weight",
            "exploration_epsilon", "practice_groundings", "competence_recency_size", "competence_window_size",
            "ees_prior_alpha", "ees_prior_beta", "planning_timeout", "test_env_seed_offset")
    for name in keys:
        value = historical[name]
        if value != "None":
            args += ["--" + name.replace("_", "-"), value]
    args += ["--kitchen-config", str(root / "inputs/kitchen-config.json"),
             "--practice-cost-config", str(root / "inputs/costs.json"),
             "--practice-reset-policy", "never", "--no-scene-bg", "--no-early-stop",
             "--defer-rendering", "--initial-measurement", "--checkpoint-cycles",
             "--measure-after-learning-updates", "1", "2", "--measurement-interval-steps", "200000",
             "--max-steps-per-interaction", "2", "--num-test-tasks", "1",
             "--evaluation-workers", "1", "--evaluation-task-rng", "per-task",
             "--evaluation-policy", "method", "--record-sampler-draws",
             "--pomdp-compress-decision-log"]
    # Current Tossing default selects its own deployment method; no legacy override.
    return args


def stage(root, source, name, result_root, flags):
    output = result_root / "pomdp/0"
    command = [str(source / "scripts/with_env.sh"), "python", "scripts/run_sweep.py",
               "--env", "kitchen_recycling3d", "--methods", "pomdp", "--num-seeds", "1",
               "--max-workers", "1", "--max-spawn-attempts", "1", "--results-root", str(result_root),
               "--shared-args", shlex.join(flags)]
    write(root / f"{name}-argv.json", command)
    started = time.time()
    with (root / "logs" / f"{name}.log").open("x") as log:
        result = subprocess.run(command, cwd=source, stdout=log, stderr=subprocess.STDOUT, check=False)
    write(root / f"{name}-exit.json", {"returncode": result.returncode, "started_unix": started, "ended_unix": time.time()})
    if result.returncode:
        raise RuntimeError(f"stage {name} failed; inspect its log")
    status = json.loads((output / "status.json").read_text())
    if status["phase"] != "paused":
        raise RuntimeError(f"stage {name} did not pause cleanly: {status}")
    shutil.copy2(output / "checkpoint.pickle", root / f"{name}-checkpoint.pickle")
    shutil.copy2(output / "step_evaluations.json", root / f"{name}-evaluations.json")
    for filename in ("sampler_draws.jsonl", "sampler_proposals.jsonl"):
        if (output / filename).exists():
            shutil.copy2(output / filename, root / f"{name}-{filename}")
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    source = (root / "source").resolve()
    preflight(root, source)
    flags = shared_flags(root)
    write(root / "smoke-deviations.json", {
        "historical_config_sha256": digest(root / "inputs/historical-config.json"),
        "kitchen_config_sha256": digest(root / "inputs/kitchen-config.json"),
        "costs_sha256": digest(root / "inputs/costs.json"),
        "fixed_seed": 0, "arm": "Curtis", "domain": "kitchen_recycling3d", "retained_total_budget": 200000,
        "smoke_only": {"action_slots_per_cycle": 2, "heldout_tasks": 1, "evaluation_workers": 1,
        "measurement_interval_steps": 200000, "measure_after_learning_updates": [1, 2],
        "record_sampler_draws": True, "reason": "bounded continuation validation; recorder continuation preserved"},
        "not_a_hypothesis_test_or_sweep": True, "shared_argv": flags})
    resumed_root = root / "results/resumed"
    reference_root = root / "results/reference"
    resumed = stage(root, source, "cycle1", resumed_root, flags + ["--stop-after-cycles", "1"])
    stage(root, source, "cycle2", resumed_root, flags + ["--stop-after-cycles", "1", "--resume", str(resumed)])
    reference = stage(root, source, "reference", reference_root, flags + ["--stop-after-cycles", "2"])
    subprocess.run([str(source / "scripts/with_env.sh"), "python", str(root / "tools/compare.py"),
                    "--root", str(root), "--resumed", str(resumed), "--reference", str(reference)], cwd=source, check=True)


if __name__ == "__main__":
    main()
