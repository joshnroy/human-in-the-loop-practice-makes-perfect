"""Local comparator regression checks on trusted saved smoke state; no simulation."""

import importlib.util
from pathlib import Path
import re

import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("semantic_compare", ROOT / "tools/compare.py")
COMPARE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(COMPARE)


def method(kind="resumed"):
    return COMPARE.load(ROOT / f"attempt2/results/{kind}/pomdp/0/checkpoint.pickle")["method"]


def test_actual_method_state_matches_without_external_repr_or_log_noise():
    a, b = method(), method("reference")
    assert a._pomdp_state.expected_execution_costs != b._pomdp_state.expected_execution_costs
    assert COMPARE.fingerprint(a) == COMPARE.fingerprint(b)


def test_changed_cost_value_still_changes_method_fingerprint():
    a, b = method(), method()
    forecasts = dict(a._pomdp_state.expected_execution_costs)
    forecasts[next(iter(forecasts))] += 0.01
    a._pomdp_state = a._pomdp_state.model_copy(update={"expected_execution_costs": forecasts})
    assert COMPARE.fingerprint(a) != COMPARE.fingerprint(b)


def test_changed_sampler_weight_still_changes_method_fingerprint():
    a, b = method(), method()
    ca = next(iter(a._samplers.values()))._classifier
    cb = next(iter(b._samplers.values()))._classifier
    ca._net = torch.nn.Linear(2, 1)
    cb._net = torch.nn.Linear(2, 1)
    cb._net.load_state_dict(ca._net.state_dict())
    assert COMPARE.fingerprint(a) == COMPARE.fingerprint(b)
    with torch.no_grad():
        ca._net.weight[0, 0] += 1.0
    assert COMPARE.fingerprint(a) != COMPARE.fingerprint(b)


@pytest.mark.parametrize(
    "replacement", ["malformed", "unknown-grounding", "unknown-type", "expression"]
)
def test_malformed_or_unmatched_cost_key_fails(replacement):
    a = method()
    forecasts = dict(a._pomdp_state.expected_execution_costs)
    key = next(iter(forecasts))
    value = forecasts.pop(key)
    if replacement == "malformed":
        changed = "not a GroundSkill"
    elif replacement == "unknown-grounding":
        changed = key.replace("Object(name='cube_0'", "Object(name='unknown_cube'")
    elif replacement == "unknown-type":
        changed = key.replace("tossing3d_robot", "unknown_robot_type")
    else:
        changed = key.rsplit(" objects=", 1)[0] + " objects=__import__('os').system('false')"
    assert changed != key
    forecasts[changed] = value
    a._pomdp_state = a._pomdp_state.model_copy(update={"expected_execution_costs": forecasts})
    with pytest.raises(ValueError):
        COMPARE.fingerprint(a)


def test_missing_cost_key_fails():
    a = method()
    forecasts = dict(a._pomdp_state.expected_execution_costs)
    forecasts.pop(next(iter(forecasts)))
    a._pomdp_state = a._pomdp_state.model_copy(update={"expected_execution_costs": forecasts})
    with pytest.raises(ValueError, match="bijection"):
        COMPARE.fingerprint(a)


def test_duplicate_semantic_cost_key_fails():
    a = method()
    forecasts = dict(a._pomdp_state.expected_execution_costs)
    key = next(iter(forecasts))
    changed = re.sub(r"0x[0-9a-f]+", "0xdeadbeef", key)
    assert changed != key
    forecasts[changed] = forecasts[key]
    a._pomdp_state = a._pomdp_state.model_copy(update={"expected_execution_costs": forecasts})
    with pytest.raises(ValueError, match="duplicate"):
        COMPARE.fingerprint(a)


def test_changed_cached_sas_payload_still_changes_method_fingerprint():
    a, b = method(), method()
    result = next(iter(a._translation_cache._results.values()))
    result.sas_str = (result.sas_str or "") + "\nsemantic difference\n"
    assert COMPARE.fingerprint(a) != COMPARE.fingerprint(b)


def test_changed_cached_diagnostic_text_does_not_change_method_fingerprint():
    a, b = method(), method()
    result = next(iter(a._translation_cache._results.values()))
    result.fd_output += "\ntiming and temporary path diagnostics\n"
    assert COMPARE.fingerprint(a) == COMPARE.fingerprint(b)
