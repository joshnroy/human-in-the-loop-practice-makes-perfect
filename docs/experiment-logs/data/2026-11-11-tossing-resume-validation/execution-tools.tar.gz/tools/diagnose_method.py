"""Read-only diff of trusted frozen method checkpoints; never create a simulator."""

import importlib.util
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("validation_compare", ROOT / "tools/compare.py")
COMPARE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(COMPARE)


def diff(left, right, path="$", differences=None):
    differences = [] if differences is None else differences
    if type(left) is not type(right):
        differences.append({"path": path, "resumed": left, "reference": right})
    elif isinstance(left, dict):
        if set(left) == set(right) == {"mapping"}:
            a = {json.dumps(key, sort_keys=True): (key, val) for key, val in left["mapping"]}
            b = {json.dumps(key, sort_keys=True): (key, val) for key, val in right["mapping"]}
            for key in sorted(set(a) | set(b)):
                label = a.get(key, b.get(key))[0]
                suffix = label if isinstance(label, str) else json.dumps(label, sort_keys=True)[:180]
                if key not in a or key not in b:
                    differences.append({"path": f"{path}.{suffix}", "resumed": a.get(key), "reference": b.get(key)})
                else:
                    diff(a[key][1], b[key][1], f"{path}.{suffix}", differences)
        else:
            for key in sorted(set(left) | set(right)):
                if key not in left or key not in right:
                    differences.append({"path": f"{path}.{key}", "resumed": left.get(key), "reference": right.get(key)})
                else:
                    diff(left[key], right[key], f"{path}.{key}", differences)
    elif isinstance(left, list):
        if len(left) != len(right):
            differences.append({"path": path + ".length", "resumed": len(left), "reference": len(right)})
        for i, (a, b) in enumerate(zip(left, right)):
            diff(a, b, f"{path}[{i}]", differences)
    elif left != right:
        differences.append({"path": path, "resumed": left, "reference": right})
    return differences


def main():
    data = ROOT / "attempt2/results"
    a = COMPARE.load(data / "resumed/pomdp/0/checkpoint.pickle")["method"]
    b = COMPARE.load(data / "reference/pomdp/0/checkpoint.pickle")["method"]
    def state(value):
        return {**vars(value), **(getattr(value, "__pydantic_private__", None) or {})}
    left, right = state(a), state(b)
    fields = {}
    for name in sorted(set(left) | set(right)):
        if name in COMPARE.IGNORED:
            continue
        fields[name] = {"equal": COMPARE.fingerprint(left.get(name)) == COMPARE.fingerprint(right.get(name))}
    differences = diff(COMPARE.normalize(a), COMPARE.normalize(b))
    def costs(value):
        result = {}
        for key, cost in value._pomdp_state.expected_execution_costs.items():
            skill = re.match(r"skill=Skill\(name='([^']+)'", key).group(1)
            names = tuple(re.findall(r"Object\(name='([^']+)'", key))
            stable = skill + "(" + ",".join(names) + ")"
            if stable in result:
                raise ValueError("duplicate semantic cost key")
            result[stable] = cost
        return result
    beliefs = {key: {"resumed": COMPARE.fingerprint(getattr(a._pomdp_state, key)), "reference": COMPARE.fingerprint(getattr(b._pomdp_state, key))} for key in type(a._pomdp_state).model_fields if key != "expected_execution_costs"}
    sampler_fingerprints = {key: {"resumed": COMPARE.fingerprint(a._samplers[key]), "reference": COMPARE.fingerprint(b._samplers[key])} for key in a._samplers.keys() | b._samplers.keys()}
    translations = [{"key_sha256": COMPARE.fingerprint(key), "sas_identical": left.sas_str == b._translation_cache._results[key].sas_str, "resumed_sas": COMPARE.fingerprint(left.sas_str), "reference_sas": COMPARE.fingerprint(b._translation_cache._results[key].sas_str), "raw_fd_output_identical": left.fd_output == b._translation_cache._results[key].fd_output} for key, left in a._translation_cache._results.items()]
    summary = {"fields_compared": len(fields), "different_fields": [name for name, row in fields.items() if not row["equal"]], "difference_count": len(differences), "cost_values": {"resumed": costs(a), "reference": costs(b)}, "belief_state_fields": beliefs, "samplers": sampler_fingerprints, "translation_entries": translations, "different_leaf_paths": [{"prefix": row["path"][:120], "suffix": row["path"][-90:]} for row in differences]}
    output = {"type": f"{type(a).__module__}.{type(a).__qualname__}", "field_comparison": fields, "summary": summary, "difference_count": len(differences), "differences": differences}
    (ROOT / "attempt2/method-diagnosis.json").write_text(json.dumps(output, indent=2) + "\n")
    (ROOT / "attempt2/method-diagnosis-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
