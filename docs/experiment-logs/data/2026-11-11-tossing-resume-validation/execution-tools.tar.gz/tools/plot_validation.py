"""Plot recorded checkpoint-proof stages and practice accounting, including partial runs."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

BLUE = "#0072B2"
GREY = "#999999"


def read(path, default):
    return json.loads(path.read_text()) if path.exists() else default


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    root = args.input_root.resolve()
    run = root / "results/resumed/pomdp/0"
    rows = read(run / "step_evaluations.json", None)
    if rows is None:
        rows = read(root / "cycle1-evaluations.json", [])
    if not rows:
        raise ValueError("No recorded evaluation/accounting rows; no proof figure generated")
    if len({row["index"] for row in rows}) != len(rows):
        raise ValueError("Repeated evaluation indices must be resolved before plotting")
    events_file = run / "step_events.jsonl"
    events = (
        [json.loads(line) for line in events_file.read_text().splitlines() if line.strip()]
        if events_file.exists()
        else []
    )
    by_index = {row["index"]: row for row in rows}
    updates = {row["cycle"] + 1 for row in events if row["event"] == "learning_update"}
    if not events:
        updates = {int(row.get("learning_updates", 0)) for row in rows}
    restarted = any(row["event"] == "resume" for row in events)
    comparison = read(root / "comparison.json", {})
    passed = comparison.get("passed")
    parity_label = (
        "Continuation parity passed"
        if passed is True
        else "Continuation parity mismatch"
        if passed is False
        else "Continuation parity pending"
    )
    identity = read(root / "inputs/identity.json", {})
    positions = {0: 0, 1: 2, 2: 5}
    labels = ["Eval 0", "Practice 1", "Eval 1", "Restart", "Practice 2", "Eval 2"]
    present = [
        bool(by_index.get(0, {}).get("complete")),
        1 in updates,
        bool(by_index.get(1, {}).get("complete")),
        restarted,
        2 in updates,
        bool(by_index.get(2, {}).get("complete")),
    ]
    unexpected = set(by_index) - positions.keys()
    if unexpected:
        raise ValueError(f"Unexpected proof evaluations: {sorted(unexpected)}")
    points = [
        {
            "evaluation": index,
            "x": positions[index],
            "robot_steps": int(row["robot_steps"]),
            "physical_cost": float(row["physical_cost"]),
            "evaluation_control_steps": sum(int(task["steps"]) for task in row.get("tasks", [])),
            "complete": bool(row.get("complete")),
        }
        for index, row in sorted(by_index.items())
    ]
    if passed is True and not all(present):
        raise ValueError("Comparison passes but a required stage lacks recorded evidence")
    plt.rcParams.update({
        "font.size": 10,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })
    fig, axes = plt.subplots(3, 1, figsize=(11.5, 6.4), gridspec_kw={"height_ratios": [1.2, 1, 1]})
    fig.suptitle(
        f"Tossing simulation checkpoint proof — Curtis seed 0\n{parity_label}; one run (n=1)",
        y=0.99,
    )
    timeline = axes[0]
    timeline.plot(range(6), [0] * 6, color=GREY, linewidth=1.2, zorder=1)
    for x, (label, observed) in enumerate(zip(labels, present, strict=True)):
        timeline.scatter(
            [x],
            [0],
            color=BLUE if observed else "white",
            edgecolor=BLUE if observed else GREY,
            s=100,
            zorder=3,
        )
        timeline.text(
            x, 0.24, label, ha="center", va="bottom", weight="bold" if observed else "normal"
        )
        timeline.text(
            x,
            -0.24,
            "recorded" if observed else "not confirmed",
            ha="center",
            va="top",
            fontsize=8,
            color=BLUE if observed else GREY,
        )
    for point in points:
        timeline.text(
            point["x"],
            -0.58,
            f"evaluation: {point['evaluation_control_steps']} control ticks",
            ha="center",
            fontsize=8,
        )
    timeline.set_ylim(-0.9, 0.65)
    timeline.set_xlim(-0.35, 5.35)
    timeline.set_axis_off()
    timeline.text(
        0.5,
        1.02,
        "Protocol order; horizontal spacing is not elapsed time",
        transform=timeline.transAxes,
        ha="center",
        fontsize=8,
    )
    for ax, key, ylabel in zip(
        axes[1:],
        ("robot_steps", "physical_cost"),
        ("Practice robot\ncontrol ticks", "Practice physical\ncost (units)"),
        strict=True,
    ):
        xs = [point["x"] for point in points]
        ys = [point[key] for point in points]
        ax.plot(xs, ys, color=BLUE, marker="o", linewidth=2)
        for x, y in zip(xs, ys, strict=True):
            ax.annotate(
                f"{y:,}" if isinstance(y, int) else f"{y:g}",
                (x, y),
                xytext=(0, 7),
                textcoords="offset points",
                ha="center",
                color=BLUE,
            )
        ax.set_ylabel(ylabel)
        ax.set_ylim(bottom=0, top=max(ys + [1]) * 1.3)
        ax.grid(axis="y", alpha=0.2)
        ax.set_xticks(range(6), labels)
        ax.set_xlim(-0.35, 5.35)
    axes[1].set_xticklabels([])
    axes[2].set_xlabel(
        "Accounting sampled at evaluations; held-out evaluation ticks are excluded from practice totals"
    )
    fig.text(
        0.01,
        0.015,
        f"Source {identity.get('source_commit', 'unavailable')[:12]} · smoke scope: 2 action slots/cycle, 1 held-out task · no efficacy inference",
        fontsize=8,
    )
    fig.tight_layout(rect=(0, 0.045, 1, 0.92))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for extension in ("png", "svg"):
        fig.savefig(
            args.output_dir / f"tossing-resume-validation.{extension}", dpi=180, bbox_inches="tight"
        )
    plt.close(fig)
    metadata = {
        "input_root": str(root),
        "source_commit": identity.get("source_commit"),
        "comparison_passed": passed,
        "stages": dict(zip(labels, present, strict=True)),
        "accounting": points,
        "scope": "Curtis seed0 continuation proof only; no hypothesis tests or efficacy inference",
    }
    (args.output_dir / "tossing-resume-validation.json").write_text(
        json.dumps(metadata, indent=2) + "\n"
    )
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
