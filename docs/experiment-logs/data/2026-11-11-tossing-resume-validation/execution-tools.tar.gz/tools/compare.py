"""Compare trusted validation outputs without restoring or stepping any simulator."""

import argparse
import ast
import dataclasses
import collections
import functools
import enum
import hashlib
import inspect
import json
import pickle
import re
from pathlib import Path

import numpy as np

IGNORED = {
    "header",
    "elapsed_seconds",
    "written_unix",
    "updated_unix",
    "output_dir",
    "output_path",
    "decision_log",
    "draw_recorder",
    "ees_decision_log",
    "policy_file_sha256",
    "policy_sha256",
    "git_dirty",
    "git_commit",
    "event_log_bytes",
    "checkpoint_written_unix",
    "seconds",
    "timing",
    "timestamp",
}


class Reference:
    def __init__(self, name):
        self.name = name

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return Reference(self.name + "." + name)


class RecorderView:
    def __setstate__(self, state):
        self.state = state


class ReadOnlyCheckpoint(pickle.Unpickler):
    def persistent_load(self, name):
        return Reference(name)

    def find_class(self, module, name):
        if name == "SamplerDrawRecorder":
            return RecorderView
        return super().find_class(module, name)


def load(path):
    with path.open("rb") as stream:
        pickle.load(stream)
        return ReadOnlyCheckpoint(stream).load()


QUOTED = r"(?:'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\")"
SKILL_NAME = re.compile(r"^skill=Skill\(name=(" + QUOTED + r"),")
BOUND_OBJECT = re.compile(
    r"Object\(name=(?P<name>"
    + QUOTED
    + r"), type=Type\(name=(?P<type>"
    + QUOTED
    + r"), feature_names=(?P<features>\((?:"
    + QUOTED
    + r"(?:,\s*)?)*\))\)\)"
)


def ground_skill_identity(ground):
    return (
        ground.skill.name,
        tuple((obj.name, obj.type.name, tuple(obj.type.feature_names)) for obj in ground.objects),
    )


def parsed_ground_skill_identity(text):
    """Read only quoted literals; never evaluate arbitrary serialized expressions."""
    if not isinstance(text, str):
        raise ValueError("cost forecast key must be a GroundSkill repr string")
    skill = SKILL_NAME.match(text)
    if skill is None or " objects=" not in text:
        raise ValueError("malformed cost forecast GroundSkill key")
    tail = text.rsplit(" objects=", 1)[1]
    objects = []
    residue = []
    position = 0
    for match in BOUND_OBJECT.finditer(tail):
        residue.append(tail[position : match.start()])
        name, typename, features = (
            ast.literal_eval(match.group(field)) for field in ("name", "type", "features")
        )
        if not isinstance(features, tuple) or not all(isinstance(f, str) for f in features):
            raise ValueError("malformed bound-object feature names")
        objects.append((name, typename, features))
        position = match.end()
    residue.append(tail[position:])
    if not re.fullmatch(r"[\s(),]*", "".join(residue)):
        raise ValueError("malformed cost forecast bound-object tuple")
    return (ast.literal_eval(skill.group(1)), tuple(objects))


def canonical_execution_costs(method):
    """Keep every cost and require a bijection with the method's exact groundings."""
    identities = [ground_skill_identity(g) for g in method._pomdp_model.ground_skills]
    if len(identities) != len(set(identities)):
        raise ValueError("ground skills do not have unique semantic identities")
    expected = set(identities)
    result = {}
    for key, value in method._pomdp_state.expected_execution_costs.items():
        parsed = parsed_ground_skill_identity(key)
        if parsed not in expected:
            raise ValueError("cost forecast key matches no method ground skill")
        if parsed in result:
            raise ValueError("duplicate semantic cost forecast key")
        result[parsed] = value
    if set(result) != expected:
        raise ValueError("cost forecast keys are not a bijection with method ground skills")
    return result


def normalize(value, stack=None):
    stack = set() if stack is None else stack
    if value is None or isinstance(value, str | bool | int):
        return value
    if isinstance(value, float):
        return value if np.isfinite(value) else repr(value)
    if isinstance(value, np.generic):
        return normalize(value.item(), stack)
    if isinstance(value, np.ndarray):
        return {
            "dtype": str(value.dtype),
            "shape": list(value.shape),
            "values": normalize(value.tolist(), stack),
        }
    if isinstance(value, np.dtype):
        return {"numpy_dtype": str(value)}
    if isinstance(value, np.random.RandomState):
        return normalize(value.get_state(), stack)
    if isinstance(value, collections.deque):
        return {"deque": normalize(list(value), stack), "maxlen": value.maxlen}
    if isinstance(value, functools.partial):
        return {
            "partial": normalize(value.func, stack),
            "args": normalize(value.args, stack),
            "keywords": normalize(value.keywords, stack),
        }
    if isinstance(value, np.random.Generator):
        return normalize(value.bit_generator.state, stack)
    if isinstance(value, Path):
        return {"path_basename": value.name}
    if isinstance(value, bytes):
        return {"bytes_sha256": hashlib.sha256(value).hexdigest()}
    if isinstance(value, enum.Enum):
        return normalize(value.value, stack)
    if isinstance(value, Reference):
        return {"live_reference": value.name}
    if inspect.isclass(value):
        return {"class": f"{value.__module__}.{value.__qualname__}"}
    if inspect.isfunction(value) or inspect.ismethod(value) or inspect.isbuiltin(value):
        return {"callable": f"{value.__module__}.{value.__qualname__}"}
    import torch

    if isinstance(value, torch.Tensor):
        return normalize(value.detach().cpu().numpy(), stack)
    if id(value) in stack:
        return {"cycle_reference": f"{type(value).__module__}.{type(value).__qualname__}"}
    stack = stack | {id(value)}
    if isinstance(value, dict):
        rows = [
            (normalize(k, stack), normalize(v, stack))
            for k, v in value.items()
            if not isinstance(k, str) or k not in IGNORED
        ]
        return {"mapping": sorted(rows, key=lambda row: json.dumps(row[0], sort_keys=True))}
    if isinstance(value, list | tuple):
        return [normalize(v, stack) for v in value]
    if isinstance(value, set | frozenset):
        return sorted(
            (normalize(v, stack) for v in value), key=lambda row: json.dumps(row, sort_keys=True)
        )
    if dataclasses.is_dataclass(value):
        fields = {f.name: getattr(value, f.name) for f in dataclasses.fields(value)}
    elif hasattr(value, "__dict__"):
        fields = {**vars(value), **(getattr(value, "__pydantic_private__", None) or {})}
    elif hasattr(type(value), "__slots__"):
        slots = [
            name
            for cls in type(value).__mro__
            for name in getattr(cls, "__slots__", ())
            if name not in {"__dict__", "__weakref__"}
        ]
        fields = {name: getattr(value, name) for name in slots if hasattr(value, name)}
    else:
        raise TypeError(f"unhandled checkpoint semantic type: {type(value)!r}")
    if type(value).__name__ == "Tossing3DPomdpMethod":
        # Repr keys include callable addresses and unordered predicate reprs. The
        # method's groundings remain fully compared elsewhere; retain every cost.
        fields["_pomdp_state"] = value._pomdp_state.model_copy(
            update={"expected_execution_costs": canonical_execution_costs(value)}
        )
    if (type(value).__module__, type(value).__name__) == (
        "hitl_pmp.planning.types",
        "TranslationResult",
    ):
        # External FD diagnostics include temp paths, timing and peak memory. Cache
        # keys and exact SAS payload (including None for failure) remain compared.
        fields.pop("fd_output")
    return {
        "type": f"{type(value).__module__}.{type(value).__qualname__}",
        "state": normalize(fields, stack),
    }


def fingerprint(value):
    encoded = json.dumps(normalize(value), sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def events(output):
    raw = [json.loads(row) for row in (output / "step_events.jsonl").read_text().splitlines()]
    return [
        row
        for row in raw
        if row["event"]
        in {"session_start", "robot", "human", "stop", "learning_update", "measurement"}
    ]


def compare(root, resumed, reference, report_path=None):
    a, b = load(resumed / "checkpoint.pickle"), load(reference / "checkpoint.pickle")
    checks = {}
    for field in (
        "method",
        "accounting",
        "metrics",
        "cycle",
        "robot_invocations",
        "learning_updates",
        "reset_counts",
        "records",
        "evaluations",
        "clock",
        "env_state",
        "simulation_state",
        "rngs",
        "stop_streak",
        "zero_step_streak",
        "no_robot_action_streak",
    ):
        checks[field] = {"resumed": fingerprint(a[field]), "reference": fingerprint(b[field])}
    checks["events"] = {
        "resumed": fingerprint(events(resumed)),
        "reference": fingerprint(events(reference)),
    }
    rows_a = json.loads((resumed / "step_evaluations.json").read_text())
    rows_b = json.loads((reference / "step_evaluations.json").read_text())
    checks["evaluation_json"] = {"resumed": fingerprint(rows_a), "reference": fingerprint(rows_b)}
    for filename in ("sampler_draws.jsonl", "sampler_proposals.jsonl"):
        path_a, path_b = resumed / filename, reference / filename
        if path_a.exists() != path_b.exists():
            checks[filename] = {"resumed": str(path_a.exists()), "reference": str(path_b.exists())}
        elif path_a.exists():
            rows1 = [json.loads(row) for row in path_a.read_text().splitlines()]
            rows2 = [json.loads(row) for row in path_b.read_text().splitlines()]
            checks[filename] = {"resumed": fingerprint(rows1), "reference": fingerprint(rows2)}
    structural = {
        "two_cycles": a["cycle"] == b["cycle"] == 2,
        "two_updates": a["learning_updates"] == b["learning_updates"] == 2,
        "eval0_once": [row["index"] for row in rows_a] == [0, 1, 2],
        "evals_complete": all(row["complete"] for row in rows_a),
        "canonical_deployment": all(
            row.get("deployment_policy", {}).get("kind") == "tossing_canonical"
            for row in rows_a + rows_b
        ),
        "first_boundary": load(root / "cycle1-checkpoint.pickle")["cycle"] == 1,
    }
    for filename in ("sampler_draws.jsonl", "sampler_proposals.jsonl"):
        first = root / f"cycle1-{filename}"
        if first.exists():
            structural["preserved_prefix_" + filename] = (
                (resumed / filename).read_bytes().startswith(first.read_bytes())
            )
    diagnostics = {}
    for label, payload in (("resumed", a), ("reference", b)):
        cache = payload["method"]._translation_cache._results
        diagnostics[label] = sorted(
            (
                {
                    "cache_key_sha256": fingerprint(key),
                    "sas_sha256": fingerprint(value.sas_str),
                    "raw_fd_output_sha256": hashlib.sha256(value.fd_output.encode()).hexdigest(),
                }
                for key, value in cache.items()
            ),
            key=lambda row: row["cache_key_sha256"],
        )
    report = {
        "hashes": checks,
        "structural": structural,
        "passed": all(row["resumed"] == row["reference"] for row in checks.values())
        and all(structural.values()),
        "normalization_omits": sorted(IGNORED),
        "semantic_normalization": {
            "cost_forecast_keys": "parse skill and bound object names/types/features with regex and literal_eval; require exact ground-skill bijection; retain every value",
            "cached_fd_output": "exclude external diagnostic text containing temporary paths, timing and memory; retain exact cache keys and SAS payloads",
        },
        "raw_external_diagnostics": diagnostics,
    }
    (report_path or root / "comparison.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n"
    )
    if not report["passed"]:
        raise AssertionError(
            "continuation differs; inspect comparison.json; do not change algorithms to reconcile it"
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--resumed", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    args = parser.parse_args()
    compare(args.root, args.resumed, args.reference)
